import { useState } from 'react';
import Button from '../Button/button.jsx';

const Auth = () => {
  const [isSignup, setIsSignup] = useState(false);

  const toggleAuthMode = () => {
    setIsSignup((prev) => !prev);
  };
  
  return (
    <>
      <form action="">
        <input id='fullName' type='text' placeholder='Full Name' style={{ display: isSignup ? 'block' : 'none' }} />
        <input id='emailID' type="email" placeholder='example@email.com' />
        <input type="password" placeholder='Password' />
        <Button type='submit' text={isSignup ? "Sign Up" : "Login"} />
      </form>
      <p onClick={toggleAuthMode}>{isSignup ? "Already have an account? Login" : "Don't have an account? Sign Up"}</p>
    </>
  )
}

export default Auth